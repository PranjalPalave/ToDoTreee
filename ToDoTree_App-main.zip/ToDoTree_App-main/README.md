# ToDoTree the mobile app

A Flutter application mainly written using Dart.

A to-do list app where all tasks are saved to a Firestore database, implementing CRUD. The app syncs across multiple
devices and emphasizes a user-friendly and intuitive UI. 

